In alphabetical order:

  1. Brandon Goldman <brandon.goldman@gmail.com>
  2. Fatima Villanueva (Kaira) <fzf.villanueva@gmail.com>
  3. Gordon Breuer <mail@gordon-breuer.de>
  4. Jorge Arias <mail@jorgearias.cl>
  5. Jose Zamudio <jose.zamudiobarrera@postgrad.manchester.ac.uk>
  6. Jørn Ølmheim <jorn@olmheim.com>
  7. Kartik Arora <chipset95@yahoo.co.in>
  8. Marcus Eisele <marcus.eisele@gmail.com>
  9. Nathan Jaremkio <njaremko@gmail.com>
  10. Panos Sakkos <panos.sakkos@protonmail.com>
  11. Prashant Solanki <prs.solanki@live.com>
  12. Sergey Lysenko <soulwish.ls@gmail.com>
